import React, { useState } from 'react';
import { Search, Filter, Sparkles } from 'lucide-react';
import { StockCard } from './StockCard';
import type { Stock } from '../types';

// Mock data - In a real application, this would come from an API
const mockStocks: Stock[] = [
  {
    symbol: 'AAPL',
    companyName: 'Apple Inc.',
    institutionalOwnership: {
      currentQuarter: 72.5,
      previousQuarter: 70.2,
      change: 2.3,
      isNewPosition: false
    },
    price: 175.34,
    sector: 'Technology',
    topInstitutions: [
      { name: 'Vanguard Group', sharesHeld: 1345000000, changeInPosition: 15000000, isNewPosition: false },
      { name: 'BlackRock Inc.', sharesHeld: 1020000000, changeInPosition: 12000000, isNewPosition: false },
      { name: 'State Street Corp', sharesHeld: 600000000, changeInPosition: 8000000, isNewPosition: false }
    ]
  },
  {
    symbol: 'PLTR',
    companyName: 'Palantir Technologies Inc.',
    institutionalOwnership: {
      currentQuarter: 25.8,
      previousQuarter: 0,
      change: 25.8,
      isNewPosition: true
    },
    price: 24.85,
    sector: 'Technology',
    topInstitutions: [
      { name: 'Renaissance Technologies', sharesHeld: 50000000, changeInPosition: 50000000, isNewPosition: true },
      { name: 'ARK Investment Management', sharesHeld: 30000000, changeInPosition: 30000000, isNewPosition: true },
      { name: 'Vanguard Group', sharesHeld: 25000000, changeInPosition: 25000000, isNewPosition: true }
    ]
  },
  {
    symbol: 'SOFI',
    companyName: 'SoFi Technologies, Inc.',
    institutionalOwnership: {
      currentQuarter: 18.5,
      previousQuarter: 0,
      change: 18.5,
      isNewPosition: true
    },
    price: 8.92,
    sector: 'Financial Services',
    topInstitutions: [
      { name: 'Silver Lake Partners', sharesHeld: 80000000, changeInPosition: 80000000, isNewPosition: true },
      { name: 'SoftBank Vision Fund', sharesHeld: 65000000, changeInPosition: 65000000, isNewPosition: true },
      { name: 'Vanguard Group', sharesHeld: 40000000, changeInPosition: 40000000, isNewPosition: false }
    ]
  },
  {
    symbol: 'MSFT',
    companyName: 'Microsoft Corporation',
    institutionalOwnership: {
      currentQuarter: 75.8,
      previousQuarter: 73.1,
      change: 2.7,
      isNewPosition: false
    },
    price: 338.11,
    sector: 'Technology',
    topInstitutions: [
      { name: 'Vanguard Group', sharesHeld: 950000000, changeInPosition: 20000000, isNewPosition: false },
      { name: 'BlackRock Inc.', sharesHeld: 750000000, changeInPosition: 15000000, isNewPosition: false },
      { name: 'State Street Corp', sharesHeld: 450000000, changeInPosition: 10000000, isNewPosition: false }
    ]
  }
];

export function Dashboard() {
  const [searchTerm, setSearchTerm] = useState('');
  const [minOwnershipChange, setMinOwnershipChange] = useState(0);
  const [showOnlyNewPositions, setShowOnlyNewPositions] = useState(false);

  const filteredStocks = mockStocks.filter(stock => {
    const matchesSearch = stock.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         stock.companyName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = stock.institutionalOwnership.change >= minOwnershipChange;
    const matchesNewPosition = showOnlyNewPositions ? stock.institutionalOwnership.isNewPosition : true;
    return matchesSearch && matchesFilter && matchesNewPosition;
  });

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Institutional Investment Tracker</h1>
          <p className="mt-2 text-gray-600">Track institutional buying patterns and new positions</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search by symbol or company name"
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <select
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
              value={minOwnershipChange}
              onChange={(e) => setMinOwnershipChange(Number(e.target.value))}
            >
              <option value={0}>All Changes</option>
              <option value={1}>+1% or more</option>
              <option value={2}>+2% or more</option>
              <option value={5}>+5% or more</option>
            </select>
          </div>

          <button
            className={`flex items-center gap-2 px-4 py-2 rounded-lg border ${
              showOnlyNewPositions
                ? 'bg-purple-100 border-purple-300 text-purple-700'
                : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
            }`}
            onClick={() => setShowOnlyNewPositions(!showOnlyNewPositions)}
          >
            <Sparkles className="w-4 h-4" />
            New Positions Only
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredStocks.map((stock) => (
            <StockCard key={stock.symbol} stock={stock} />
          ))}
        </div>
      </div>
    </div>
  );
}