import React from 'react';
import { TrendingUp, TrendingDown, Building2, Sparkles } from 'lucide-react';
import type { Stock } from '../types';

interface StockCardProps {
  stock: Stock;
}

export function StockCard({ stock }: StockCardProps) {
  const isPositiveChange = stock.institutionalOwnership.change > 0;

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-xl font-bold text-gray-900">{stock.symbol}</h3>
            {stock.institutionalOwnership.isNewPosition && (
              <span className="flex items-center gap-1 bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full text-xs font-medium">
                <Sparkles className="w-3 h-3" />
                New Position
              </span>
            )}
          </div>
          <p className="text-sm text-gray-600">{stock.companyName}</p>
        </div>
        <div className="flex items-center">
          <Building2 className="w-5 h-5 text-blue-600 mr-2" />
          <span className="text-sm font-medium text-gray-700">
            {stock.institutionalOwnership.currentQuarter.toFixed(2)}%
          </span>
        </div>
      </div>
      
      <div className="mt-4">
        <div className={`flex items-center ${isPositiveChange ? 'text-green-600' : 'text-red-600'}`}>
          {isPositiveChange ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}
          <span className="font-semibold">
            {isPositiveChange ? '+' : ''}{stock.institutionalOwnership.change.toFixed(2)}%
          </span>
          <span className="text-sm text-gray-600 ml-2">vs last quarter</span>
        </div>
      </div>

      <div className="mt-4">
        <h4 className="text-sm font-semibold text-gray-700 mb-2">Top Institutional Buyers</h4>
        <div className="space-y-2">
          {stock.topInstitutions.slice(0, 3).map((institution, index) => (
            <div key={index} className="flex justify-between items-center text-sm">
              <div className="flex items-center gap-2">
                <span className="text-gray-600">{institution.name}</span>
                {institution.isNewPosition && (
                  <span className="bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded-full text-xs font-medium">New</span>
                )}
              </div>
              <span className={institution.changeInPosition > 0 ? 'text-green-600' : 'text-red-600'}>
                {institution.changeInPosition > 0 ? '+' : ''}{institution.changeInPosition.toLocaleString()} shares
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}